/**
 * @file main.c
 * @author Eduardo Salvacion
 * @date April 7, 2022
 * @brief This program will simulate a course initialization and enrollment of randomly
 *        generated students
 *
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief This function generates a new course, and enrolls 20 students with each
 *        student having 8 randomly generated grades
 * 
 *        Then print all of the students enrolled, the top student, and those who are passing
 * 
 * @return int = 0
 */
int main()
{
  srand((unsigned) time(NULL));

  //Initialize a new course and store attributes
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //Enroll 20 randomly generated students to the course with each student having 8 stored grades
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  //Print the course attributes with all of the students enrolled, top student, and all of those who are passing
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}