/**
 * @file student.h
 * @author Eduardo Salvacion
 * @date April 7, 2022
 * @brief Student library for managing students' grades, including student
 *        type definition and student functions.
 */

/**
* Student type stores a book with fields first_name, last_name,
* ID, list of grades, and number of grades.
* 
*/
typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name */
  char last_name[50]; /**< the student's last name */
  char id[11];  /**< the student's 11 digit ID */
  double *grades;  /**< array of the student's grades */
  int num_grades;  /**< the student's total number of grades */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
