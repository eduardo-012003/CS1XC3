/**
 * @file course.h
 * @author Eduardo Salvacion
 * @date April 7, 2022
 * @brief Course library for managing course information, including course
 *        type definition and course functions.
 */


#include "student.h"
#include <stdbool.h>
 
/**
* Course type stores a course with fields course name, course code, 
* list of students (Student Type) enrolled, and the number of students.
* 
*/

typedef struct _course 
{
  char name[100]; /**< the course's name */
  char code[10]; /**< the course's code */
  Student *students; /**< array of students (Student Type) enrolled in the course */
  int total_students; /**< the total number of students enrolled in the course */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


